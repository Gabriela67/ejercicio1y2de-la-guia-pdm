package com.example.numeromayor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    //variables para selecionar los elementos
    public EditText numberOne;
    public EditText numberTwo;
    public EditText numberThree;
    public Button submit;
    //varibales para almacenar los valores del elementos edittext
    public String one;
    public String two;
    public String three;
    //arraylist
    public ArrayList<Integer> listNumber = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberOne = findViewById(R.id.editTextNumberOne);
        numberTwo = findViewById(R.id.editTextNumberTwo);
        numberThree = findViewById(R.id.editTextNumberThree);
        submit = findViewById(R.id.btn_ordener);

        numberOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = charSequence.toString();
                one = text;

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        numberTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = charSequence.toString();
                two = text;

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        numberThree.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = charSequence.toString();
                three = text;

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!one.isEmpty() && !two.isEmpty() && !three.isEmpty()){
                    int number_one = Integer.parseInt(one);
                    listNumber.add(number_one);
                    int numbre_two = Integer.parseInt(two);
                    listNumber.add(numbre_two);
                    int numbre_three = Integer.parseInt(three);
                    listNumber.add(numbre_three);
                    Collections.sort(listNumber);
                    String valorMayor = String.valueOf(listNumber.get(listNumber.size()-1));
                    showNumber(MainActivity.this,valorMayor);
                    listNumber.clear();
                }
            }
        });

    }

    public void showNumber(Context context,String number){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("el numero mayor es");
        builder.setMessage(number);
        builder.setPositiveButton("cerrar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();

    }
}