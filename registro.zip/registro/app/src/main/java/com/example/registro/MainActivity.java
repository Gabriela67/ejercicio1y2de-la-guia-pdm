package com.example.registro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public EditText nombre;
    public EditText edad;
    public EditText telefono;
    public ListView contenedor;
    public Button btnIngresar;
    public String nombre_valor;
    public String telefono_valor;
    public String edad_valor;
    public ArrayList<Alumno> listaAlumnos = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = findViewById(R.id.editTextNombre);
        nombre.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String nombre = charSequence.toString();
                nombre_valor = nombre;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        edad = findViewById(R.id.editTextEdad);
        edad.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String edad = charSequence.toString();
                edad_valor = edad;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        telefono = findViewById(R.id.editTextTelefono);
        telefono.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String telefono = charSequence.toString();
                telefono_valor = telefono;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        btnIngresar = findViewById(R.id.button);
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int edad_numero = Integer.parseInt(edad_valor);
                Alumno alumno = new Alumno(nombre_valor,edad_numero,telefono_valor);
                listaAlumnos.add(alumno);
                actualizarListView();
            }
        });
    }

    public void actualizarListView(){

        contenedor = findViewById(R.id.contenedorView);

        ArrayList<String> d = new ArrayList<>();
        for (Alumno alumno : listaAlumnos){
            String text = alumno.getNombre()+ "   "+ alumno.getTelefono();
            if (alumno.getedad() >= 18){
                 text += "(Mayor de edad)";
            }else {
                text += "(Menor de edad)";
            }
            d.add(text);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,d);
        contenedor.setAdapter(adapter);
    }
}