package com.example.registro;

public class Alumno {
    private String nombre;
    private int edad;
    private String telefono;

    public Alumno(String nombre,int edad,String telefono){
        this.nombre = nombre;
        this.edad = edad;
        this.telefono = telefono;
    }

    public String getNombre(){
        return nombre;
    }

    public int getedad(){
        return edad;
    }

    public String getTelefono(){
        return telefono;
    }
}
